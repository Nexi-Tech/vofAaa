import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../../FillPages/AppBar.dart';
import '../../../FillPages/BackToPreviousPageButton.dart';
import '../../Spieces Of The Earth/CustomExpansionTile.dart';


class Catholic extends StatelessWidget {
  late String Title;

  Catholic(String sTitle) {
    Title = sTitle;
  }

  Widget build(BuildContext context) {
    // Strona glowna + naglowek
    return Scaffold(
      appBar: AppBarX.buildAppBar(Title),
      body: Container(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        // odstep kafelkow od krawedzi apki
        height: MediaQuery.of(context).size.height,
        color: Colors.black,
        child: CustomScrollView(
          slivers: [
            SliverFillRemaining(
              hasScrollBody: false,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[

                  BackToHomePageButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
