import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../FillPages/AppBar.dart';
import '../../../FillPages/BackToPreviousPageButton.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


import 'dart:io';

class CustomExpansionTileView extends StatelessWidget {
  final String image;
  final String title;
  final Function(String) navigateToDestination;


  CustomExpansionTileView({
    required this.image,
    required this.title,
    required this.navigateToDestination,

  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        navigateToDestination(title);
      },
      child: Container(
        margin: EdgeInsets.only(left: 10, right: 10, top: 10, bottom: 10),
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(5),
          boxShadow: [
            BoxShadow(),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Expanded(
              flex: 1,
              child: Padding(
                padding: const EdgeInsets.all(1.0),
                child: Image.network(
                  image,
                  height: 100,
                  fit: BoxFit.fitWidth,
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Center(
                  child: Text(
                    title,
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 28,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Protestant('Protestant'),
    );
  }
}

class Protestant extends StatefulWidget {
  final String title;

  Protestant(this.title);

  @override
  _ProtestantState createState() => _ProtestantState();
}

class _ProtestantState extends State<Protestant> {
  late String Title;
  late CollectionReference prayersCollection;
  final ImagePicker _picker = ImagePicker();
  List<DocumentReference> customTiles = [];
  List<String> imagePaths = []; // Dodana lista ścieżek obrazów
  TextEditingController newPrayerTitleController = TextEditingController();

  @override
  void initState() {
    super.initState();
    Title = widget.title;
    prayersCollection = FirebaseFirestore.instance.collection('prayers');
    getPrayers();
  }



  Future<void> getPrayers() async {
    var querySnapshot = await prayersCollection.orderBy('createdAt').get();
    setState(() {
      customTiles = querySnapshot.docs.map((doc) => doc.reference).toList();
      imagePaths = querySnapshot.docs.map((doc) => doc['imageUrl'] as String).toList();
      // Uzupełnienie listy ścieżek obrazów
    });
  }



  void navigateToDetailsPage(int index, String documentId, String imagePath, String title) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DetailsPage(
          index: index,
          documentId: documentId,
          imagePath: imagePath,
          afterImagePath: '', // Dodałem pusty string dla afterImagePath
          title: title,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(Title),
      ),
      body: Column(
        children: <Widget>[

          Expanded(
            child: ListView.builder(
              itemCount: customTiles.length,
              itemBuilder: (BuildContext context, int index) {
                return FutureBuilder<DocumentSnapshot>(
                  future: customTiles[index].get(),
                  builder: (BuildContext context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                    if (snapshot.hasError) {
                      return Text("Something went wrong");
                    }

                    if (snapshot.connectionState == ConnectionState.done) {
                      Map<String, dynamic> data = snapshot.data!.data() as Map<String, dynamic>;

                      return CustomExpansionTileView(
                        image: imagePaths[index], // Użyj ścieżki obrazu z listy
                        title: data["title"],
                        navigateToDestination: (title) {
                          navigateToDetailsPage(index, customTiles[index].id, imagePaths[index], title); // Przekazanie indeksu
                        },
                      );
                    }

                    return Text("Loading");
                  },
                );
              },
            ),
          ),
        ],
      ),
      backgroundColor: Colors.black,
    );
  }
}

class DetailsPage extends StatefulWidget {
  final int index;
  final String documentId;
  final String imagePath;
  final String afterImagePath;
  final String title;


  DetailsPage({
    required this.index,
    required this.documentId,
    required this.imagePath,
    required this.afterImagePath,
    required this.title,

  });

  @override
  _DetailsPageState createState() => _DetailsPageState();
}

class _DetailsPageState extends State<DetailsPage> {
  double sliderValue = 0.5;
  late String editedTitle = ''; // Dodana inicjalizacja
  late String editedDetails = ''; // Dodana inicjalizacja
  TextEditingController titleController = TextEditingController();
  TextEditingController detailsController = TextEditingController();

  @override
  void initState() {
    super.initState();

    titleController = TextEditingController(
        text: widget.title); // Inicjalizacja wartości z widget.title

    _fetchImageDetails();
  }

  Future<void> _fetchImageDetails() async {
    try {
      DocumentSnapshot doc = await FirebaseFirestore.instance.collection(
          'ProtestantDetails').doc(widget.documentId).get();
      if (doc.exists) {
        setState(() {
          editedTitle = doc['title'] ?? ''; // Dodana obsługa null
          editedDetails = doc['details'] ?? ''; // Dodana obsługa null
          titleController.text = editedTitle;
          detailsController.text = editedDetails;
        });
      }
    } catch (e) {
      print('Error fetching image details: $e');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        centerTitle: true,
        title: Text(
          widget.title,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: CustomScrollView(
        slivers: [
          SliverFillRemaining(
            hasScrollBody: false,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Expanded(
                  flex: 1,
                  child: GestureDetector(
                    onHorizontalDragUpdate: (details) {
                      setState(() {
                        double newValue = sliderValue + details.delta.dx / 350;
                        sliderValue = newValue.clamp(0.0, 1.0);
                      });
                    },
                    child: Image.network(
                      sliderValue >= 0.5 ? widget.imagePath : widget
                          .afterImagePath,
                      height: 350,
                      width: 400,

                    ),
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: Container(
                    padding: EdgeInsets.fromLTRB(30, 5, 30, 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                          editedDetails, // Display the details as text
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
        backgroundColor: Colors.black
    );
  }
}
