import 'dart:convert';
import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:before_after/before_after.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:image_picker/image_picker.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp().then((value) {
    print("Firebase initialized");
  });
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: IsraelPastPresent('Israel Past and Present_edit'),
    );
  }
}

class ImageDetails {
  String documentId;
  String imagePath;
  String title;
  String details;
  String afterImagePath;

  ImageDetails({
    required this.documentId,
    required this.imagePath,
    required this.title,
    required this.details,
    required this.afterImagePath,
  });

  Map<String, dynamic> toJson() {
    return {
      'documentId': documentId,
      'imagePath': imagePath,
      'title': title,
      'details': details,
      'afterImagePath': afterImagePath,
    };
  }

  factory ImageDetails.fromJson(Map<String, dynamic> json) {
    return ImageDetails(
      documentId: json['documentId'],
      imagePath: json['imagePath'],
      title: json['title'],
      details: json['details'],
      afterImagePath: json['afterImagePath'],
    );
  }
}

class IsraelPastPresent extends StatefulWidget {
  final List<ImageDetails> _images = [];
  late String title;

  IsraelPastPresent(String sTitle) {
    title = sTitle;
  }

  void saveImageDetails(
      String documentId,
      String imagePath,
      String title,
      String details,
      String afterImagePath,
      ) async {
    try {
      await FirebaseFirestore.instance.collection('imageDetails').doc(documentId).set({
        'imagePath': imagePath,
        'title': title,
        'details': details,
        'afterImagePath': afterImagePath,
      }, SetOptions(merge: true));
    } catch (e) {
      print('Error updating image details: $e');
    }
  }

  @override
  _IsraelPastPresentState createState() => _IsraelPastPresentState();
}

class _IsraelPastPresentState extends State<IsraelPastPresent> {
  @override
  void initState() {
    super.initState();
    loadImagesFromFirestore(); // Load images from Firestore
  }

  Future<void> addNewTileDetails() async {
    final picker = ImagePicker();
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      File image = File(pickedFile.path);

      try {
        String fileName = image.path.split('/').last;
        await firebase_storage.FirebaseStorage.instance.ref('images/$fileName').putFile(image);
        String downloadURL = await firebase_storage.FirebaseStorage.instance.ref('images/$fileName').getDownloadURL();

        ImageDetails newImageDetails = ImageDetails(
          documentId: 'uniqueDocumentIdForImage${widget._images.length + 1}',
          imagePath: downloadURL,
          afterImagePath: '',
          title: '',
          details: '',
        );

        setState(() {
          widget._images.add(newImageDetails);
        });

        await saveImagesToFirestore();

        // Aktualizacja stanu w bazie danych
        widget.saveImageDetails(
          newImageDetails.documentId,
          newImageDetails.imagePath,
          newImageDetails.title,
          newImageDetails.details,
          newImageDetails.afterImagePath,
        );

        // Aktualizacja stanu ilości ImageDetails w bazie danych Firebase
        await FirebaseFirestore.instance.collection('imageDetails').doc('count').set({
          'count': widget._images.length,
        }, SetOptions(merge: true));
      } catch (e) {
        print('Error uploading image: $e');
      }
    }
  }



  Future<void> saveImagesToFirestore() async {
    try {
      final List<Map<String, dynamic>> imagesDataList = widget._images.map((image) => image.toJson()).toList();
      await FirebaseFirestore.instance.collection('imageDetails').doc('imagesData').set({
        'images': imagesDataList,
      }, SetOptions(merge: true));
    } catch (e) {
      print('Error saving images to Firestore: $e');
    }
  }

  Future<void> loadImagesFromFirestore() async {
    try {
      DocumentSnapshot doc = await FirebaseFirestore.instance.collection('imageDetails').doc('imagesData').get();
      if (doc.exists) {
        List<Map<String, dynamic>> imagesDataList = List<Map<String, dynamic>>.from(doc['images']);
        List<ImageDetails> images = imagesDataList.map((json) => ImageDetails.fromJson(json)).toList();
        setState(() {
          widget._images.clear();
          widget._images.addAll(images);
        });

        // Pobranie stanu ilości ImageDetails z bazy danych Firebase
        doc = await FirebaseFirestore.instance.collection('imageDetails').doc('count').get();
        if (doc.exists) {
          int count = doc['count'];
          setState(() {
            widget._images.length = count;
          });
        }
      }
    } catch (e) {
      print('Error fetching image data from Firestore: $e');
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        centerTitle: true,
        title: Text(
          widget.title,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(
              height: 5,
            ),
            Text(
              'Gallery',
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 15,
            ),
            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 30,
                ),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemBuilder: (context, index) {
                    return RawMaterialButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DetailsPage(
                              documentId: widget._images[index].documentId,
                              imagePath: widget._images[index].imagePath,
                              afterImagePath: widget._images[index].afterImagePath,
                              title: widget._images[index].title,
                              details: widget._images[index].details,
                              index: index,
                              saveImageDetails: widget.saveImageDetails,
                            ),
                          ),
                        );
                      },
                      child: Hero(
                        tag: 'logo$index',
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            image: DecorationImage(
                              image: NetworkImage(widget._images[index].imagePath), // Use NetworkImage to load images
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                  itemCount: widget._images.length,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DetailsPage extends StatefulWidget {
  String documentId;
  String imagePath;
  String afterImagePath;
  String title;
  String details;
  int index;
  Function(String, String, String, String, String) saveImageDetails;


  DetailsPage({
    required this.documentId,
    required this.imagePath,
    required this.afterImagePath,
    required this.title,
    required this.details,
    required this.index,
    required this.saveImageDetails,

  });

  @override
  _DetailsPageState createState() => _DetailsPageState();
}

class _DetailsPageState extends State<DetailsPage> {
  double sliderValue = 0.5;
  late String editedTitle;
  late String editedDetails;
  TextEditingController titleController = TextEditingController();
  TextEditingController detailsController = TextEditingController();


  Future<void> _fetchImageDetails() async {
    try {
      DocumentSnapshot doc = await FirebaseFirestore.instance.collection(
          'imageDetails').doc(widget.documentId).get();
      if (doc.exists) {
        setState(() {
          editedTitle = doc['title'];
          editedDetails = doc['details'];
          titleController.text = editedTitle;
          detailsController.text = editedDetails;
          widget.imagePath = doc['imagePath'];
          widget.afterImagePath = doc['afterImagePath'];
        });
      }
    } catch (e) {
      print('Error fetching image details: $e');
    }
  }


  @override
  void initState() {
    super.initState();
    editedTitle = widget.title;
    editedDetails = widget.details;
    titleController.text = editedTitle;
    detailsController.text = editedDetails;
    _fetchImageDetails(); // Fetch image details when the widget initializes
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        centerTitle: true,
        title: Text(
          editedTitle,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Container(
        child: CustomScrollView(
          slivers: [
            SliverFillRemaining(
              hasScrollBody: false,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Hero(
                    tag: 'logo${widget.index}',
                    child: GestureDetector(
                      onHorizontalDragUpdate: (details) {
                        setState(() {
                          double newValue = sliderValue +
                              details.delta.dx / 350;
                          sliderValue = newValue.clamp(0.0, 1.0);
                        });
                      },
                      child: BeforeAfter(
                        height: 350,
                        width: double.infinity, // Set to occupy the full width
                        before: Image.network(
                          widget.imagePath,
                          fit: BoxFit.cover,
                        ),
                        after: Image.network(
                          widget.afterImagePath,
                          fit: BoxFit.cover,
                        ),
                        thumbColor: Colors.red,
                        value: sliderValue,
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 30,
                    ),
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
                          child: Column(
                            children: <Widget>[
                              Text(
                                'Details',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                              Text(
                                editedDetails,
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      backgroundColor: Colors.black,
    );
  }
}