import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vof/SubPages/Maps/location_service.dart';

import '../../FillPages/AppBar.dart';
import '../../FillPages/SideMenu.dart';
import '../Contact/Contact.dart';
import '../Israel Past & Present/Israel Past & Present.dart';
import '../Prayers And Reflections/Prayers & Reflections.dart';
import '../Spieces Of The Earth/Spieces Of The Earth.dart';
import '../Videos Galery/Videos Galery.dart';

class MapSample extends StatefulWidget {

  const MapSample({super.key});

  @override
  State<MapSample> createState() => MapSampleState();
}

class MapSampleState extends State<MapSample> {
  final String phoneNumber = '1234567890'; // Replace with an actual phone number
  final String email = 'example@example.com'; // Replace with an actual email address

  final Completer<GoogleMapController> _controller =
  Completer<GoogleMapController>();

  TextEditingController _searchController = TextEditingController();

  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(31.768566873616884, 35.21449478029992),
    zoom: 5.0746,
  );


  //MARKER 1 (PINEZKA)
  static final Marker_kGooglePlexMarker = Marker(markerId:
  MarkerId('_kGooglePlex'),
    infoWindow: InfoWindow(title: 'Google Plex'), //TYTUL PINEZKI
    icon: BitmapDescriptor.defaultMarker,
    position: LatLng(37.42796133580664, -122.085749655962),
  );

  //38.762947782998474, -9.188232277492709

  //MARKER 2 (PINEZKA)
  static final Marker_kGooglePlexMarker2 = Marker(markerId:
  MarkerId('_kGooglePlex'),
    infoWindow: InfoWindow(title: 'Test Lisbon'), //TYTUL PINEZKI
    icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
    position: LatLng(38.762947782998474, -9.188232277492709),
  );

  //MARKER 3 (PINEZKA)
  static final Marker_kGooglePlexMarker3 = Marker(markerId:
  MarkerId('_kGooglePlex'),
    infoWindow: InfoWindow(title: 'Petra'), //TYTUL PINEZKI
    icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
    position: LatLng(30.32873219047611, 35.444694790802295),
  );


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarX.buildAppBar("Map"),
        body: Column(
          children: [
          Container(
            decoration: BoxDecoration(color: Colors.white,border: Border.all(color: Colors.black)),
            child: Row(children: [
              Expanded(child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                child: TextFormField(
                controller: _searchController,
                textCapitalization: TextCapitalization.words,
                decoration: InputDecoration(hintText: 'Search by City'),
                onChanged: (value) {
                  print(value);
                },
                style: TextStyle(color: Colors.black,),),
              )),
              IconButton(onPressed: () async {

                var place = await LocationService().getPlace(_searchController.text);
                _goToPlace(place);

              }, icon: Icon(Icons.search,color: Colors.black,),),
              ],
            ),
          ),
            Expanded(
              child: GoogleMap(
                mapType: MapType.normal,
                markers:{
                Marker_kGooglePlexMarker, //implmentacja markera 1
                  Marker_kGooglePlexMarker2, //implmentacja markera 2
                  Marker_kGooglePlexMarker3, //implmentacja markera 3

                },
                initialCameraPosition: _kGooglePlex,
                onMapCreated: (GoogleMapController controller) {
                  _controller.complete(controller);
                },
              ),
            ),
          ],
          ),




    backgroundColor: Colors.black, //kolor tła po wcisnieciu guzika

    );
  }


  Future<void> _goToPlace(Map<String, dynamic> place) async{
    final double lat = place['geometry']['location']['lat'];
    final double lng = place['geometry']['location']['lng'];
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(
      CameraPosition(target: LatLng(lat,lng), zoom: 15),
    ),
    );
  }

 }
