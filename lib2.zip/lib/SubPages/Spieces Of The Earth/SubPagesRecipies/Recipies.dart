import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../../FillPages/AppBar.dart';
import '../../../FillPages/BackToPreviousPageButton.dart';
import '../CustomExpansionTile.dart';
import 'Danie1.dart';
import 'Danie2.dart';
import 'Danie3.dart';
import 'Danie4.dart';
import 'Danie5.dart';
import 'Danie6.dart';
import 'Danie7.dart';
import 'Danie8.dart';
import 'Danie9.dart';
import 'Danie10.dart';

class Recipies extends StatelessWidget {
  late String Title;

  Recipies(String sTitle) {
    Title = sTitle;
  }

  Widget build(BuildContext context) {
    // Strona glowna + naglowek
    return Scaffold(
      appBar: AppBarX.buildAppBar(Title),
      body: Container(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        // odstep kafelkow od krawedzi apki
        height: MediaQuery.of(context).size.height,
        color: Colors.black,
        child: CustomScrollView(
          slivers: [
            SliverFillRemaining(
              hasScrollBody: false,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  //Danie 1
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Danie 1",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Danie1(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 2
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Danie 2",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Danie2(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 3
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Danie 3",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Danie3(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 4
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Danie 4",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Danie4(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 5
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Danie 5",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Danie5(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 6
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Danie 6",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Danie6(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 7
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Danie 7",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Danie7(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 8
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Danie 8",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Danie8(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 9
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Danie 9",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Danie9(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 10
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Danie 10",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Danie10(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  BackToHomePageButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
