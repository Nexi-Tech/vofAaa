import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:vof/SubPages/Spieces%20Of%20The%20Earth/SubPagesHerbsSpices/HerbsSpices10.dart';
import 'package:vof/SubPages/Spieces%20Of%20The%20Earth/SubPagesHerbsSpices/HerbsSpices2.dart';
import 'package:vof/SubPages/Spieces%20Of%20The%20Earth/SubPagesHerbsSpices/HerbsSpices3.dart';
import 'package:vof/SubPages/Spieces%20Of%20The%20Earth/SubPagesHerbsSpices/HerbsSpices4.dart';
import 'package:vof/SubPages/Spieces%20Of%20The%20Earth/SubPagesHerbsSpices/HerbsSpices5.dart';
import 'package:vof/SubPages/Spieces%20Of%20The%20Earth/SubPagesHerbsSpices/HerbsSpices6.dart';
import 'package:vof/SubPages/Spieces%20Of%20The%20Earth/SubPagesHerbsSpices/HerbsSpices7.dart';
import 'package:vof/SubPages/Spieces%20Of%20The%20Earth/SubPagesHerbsSpices/HerbsSpices8.dart';
import 'package:vof/SubPages/Spieces%20Of%20The%20Earth/SubPagesHerbsSpices/HerbsSpices9.dart';
import '../../../FillPages/AppBar.dart';
import '../../../FillPages/BackToPreviousPageButton.dart';
import '../CustomExpansionTile.dart';
import 'HerbsSpices1.dart';


class HerbsSpices extends StatelessWidget {
  late String Title;

  HerbsSpices(String sTitle) {
    Title = sTitle;
  }

  Widget build(BuildContext context) {
    // Strona glowna + naglowek
    return Scaffold(
      appBar: AppBarX.buildAppBar(Title),
      body: Container(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        // odstep kafelkow od krawedzi apki
        height: MediaQuery.of(context).size.height,
        color: Colors.black,
        child: CustomScrollView(
          slivers: [
            SliverFillRemaining(
              hasScrollBody: false,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  //Danie 1
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Herb 1",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HerbsSpices1(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 2
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Herb 2",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HerbsSpices2(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 3
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Herb 3",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HerbsSpices3(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 4
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Herb 4",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HerbsSpices4(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 5
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Herb 5",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HerbsSpices5(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 6
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Herb 6",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HerbsSpices6(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 7
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Herb 7",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HerbsSpices7(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 8
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Herb 8",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HerbsSpices8(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 9
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Herb 9",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HerbsSpices9(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  //Danie 10
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        CustomExpansionTile(
                          image: "Splash_logo",
                          title: "Herb 10",
                          navigateToDestination: (title) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HerbsSpices10(title), // tutaj trzeba zmienic strone do ktorej kieruje
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  BackToHomePageButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
