import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../SubPages/Culinary Videos/Culinary Videos_edit.dart';
import '../SubPages/Israel Past & Present/Israel Past & Present_edit.dart';
import '../SubPages/Prayers And Reflections/SubPagesProtestant/Protestant_edit.dart';
import '../SubPages/Videos Galery/Videos Galery_edit.dart';
import '../main.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});

  final user = FirebaseAuth.instance.currentUser!;

  // sign user out method
  void signUserOut() {
    FirebaseAuth.instance.signOut();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2, // Dodaj dwie zakładki
      child: Scaffold(
        backgroundColor: Colors.grey[300],
        appBar: AppBar(
          backgroundColor: Colors.grey[900],
          actions: [
            IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => Home()),
                );// Powrót na ekran poprzedni
              },
            ),
            IconButton(
              onPressed: signUserOut,
              icon: Icon(Icons.logout),
            )
          ],
          bottom: TabBar(
            tabs: [
              Tab(text: 'Dane użytkownika'), // Zakładka z danymi użytkownika
              Tab(text: 'Lista plików'), // Zakładka z listą plików
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // Widok dla zakładki "Dane użytkownika"
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  "LOGGED IN AS: " + user.email!,
                  style: TextStyle(fontSize: 20),
                ),
                // Tutaj można dodać dodatkowe elementy dotyczące danych użytkownika
              ],
            ),

            // Widok dla zakładki "Lista plików"
            ListView(
              padding: EdgeInsets.all(16.0),
              children: <Widget>[
                ListTile(
                  title: Text('Israel Past & Present_edit'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            IsraelPastPresentEdit('Israel Past and Present_edit'), // Dodaj unikalne ID dokumentu
                      ),
                    );
                  },
                ),
                ListTile(
                  title: Text('Videos Galery_edit'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            VideosGaleryEdit('Videos Galery_edit'), // Dodaj unikalne ID dokumentu
                      ),
                    );
                  },
                ),
                ListTile(
                  title: Text('Culinary Videos_edit'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            CulinaryVideosEdit('Culinary Videos_edit'), // Dodaj unikalne ID dokumentu
                      ),
                    );
                  },
                ),
                ListTile(
                  title: Text('Protestant_edit'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            ProtestantEdit('Protestant_edit'), // Dodaj unikalne ID dokumentu
                      ),
                    );
                  },
                ),
                // Tutaj można dodać inne linki do plików
              ],
            ),
          ],
        ),
      ),
    );
  }
}
