import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:vof/components/my_button.dart';
import 'package:vof/components/my_textfield.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';

class RegistrationPage extends StatefulWidget {
  RegistrationPage({super.key});

  @override
  State<RegistrationPage> createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController lastnameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();


  Future<List<String>> getEmailCredentials() async {
    // Pobierz dane do konta e-mail i hasło z Firestore
    String username = await FirebaseFirestore.instance
        .collection('admins')
        .doc('admin_document')
        .get()
        .then((doc) => doc['username']);

    String password = await FirebaseFirestore.instance
        .collection('admins')
        .doc('admin_document')
        .get()
        .then((doc) => doc['password']);

    return [username, password];
  }

  void sendEmailToSupport(String username, String password) async {
    final smtpServer = gmail(username, password);

    final message = Message()
      ..from = Address(username, 'Your Name')
      ..recipients.add('support@nexitech.pl')
      ..subject = 'Nowy użytkownik czeka na akceptację'
      ..text = 'Nowy użytkownik czeka na akceptację.';

    try {
      final sendReport = await send(message, smtpServer);
      print('Message sent: ' + sendReport.toString());
    } on MailerException catch (e) {
      print('Message not sent. Error: $e');
    }
  }

  void registerUser() async {
    showDialog(
      context: context,
      builder: (context) {
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    );

    try {
      UserCredential? userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
        email: emailController.text,
        password: passwordController.text,
      );

      // Aktualizacja profilu użytkownika
      await userCredential?.user?.updateProfile(displayName: "${nameController.text} ${lastnameController.text}");

      // Aktualizacja numeru telefonu (jeśli został podany)
      if (phoneNumberController.text.isNotEmpty) {
        await userCredential?.user?.updatePhoneNumber(PhoneAuthProvider.credential(
          verificationId: 'YOUR_VERIFICATION_ID',
          smsCode: 'SMS_CODE',
        ));
      }

      print('Name: ${nameController.text}');
      print('Lastname: ${lastnameController.text}');
      print('Email: ${emailController.text}');
      print('Password: ${passwordController.text}');
      print('Phone Number: ${phoneNumberController.text}');

      // Dane do zapisania
      Map<String, dynamic> userData = {
        'name': nameController.text,
        'lastname': lastnameController.text,
        'email': emailController.text,
        'phoneNumber': phoneNumberController.text,
      };

      // Zapisanie danych użytkownika w kolekcji 'users'
      await FirebaseFirestore.instance.collection('users').doc('userCredential').set(userData); // Zmieniono 'userCredential'

      // Pobierz dane do konta e-mail i hasło z Firestore
      List<String> credentials = await getEmailCredentials();

      // Wyślij e-mail do support@nexitech.pl
      sendEmailToSupport(credentials[0], credentials[1]);

      print('Użytkownik zarejestrowany pomyślnie: ${userCredential?.user?.email}');

      Navigator.pop(context);
    } on FirebaseAuthException catch (e) {
      Navigator.pop(context);
      print('FirebaseAuthException: ${e.message}');
    } catch (e) {
      Navigator.pop(context);
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Registration'),
      ),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              MyTextField(
                controller: nameController,
                hintText: 'Name',
                obscureText: false,
              ),
              const SizedBox(height: 10),
              MyTextField(
                controller: lastnameController,
                hintText: 'Lastname',
                obscureText: false,
              ),
              const SizedBox(height: 10),
              MyTextField(
                controller: emailController,
                hintText: 'Email',
                obscureText: false,
              ),
              const SizedBox(height: 10),
              MyTextField(
                controller: passwordController,
                hintText: 'Password',
                obscureText: true,
              ),
              const SizedBox(height: 10),
              MyTextField(
                controller: phoneNumberController,
                hintText: 'Phone Number (optional)',
                obscureText: false,
              ),
              const SizedBox(height: 20),
              MyButton(
                onTap: registerUser,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
